#
#   Author:         Carl Grissom
#   Date:           09/21/2019
#   Project:        Bayer Sentiment Analysis CS 499
#   Filename:       
#   
#   Description:
#
#


from django.shortcuts import render
from django.http import HttpResponse

# user defined imports 
from .models import Tweet, WordList
from . import twittersearch as ts

# Create your views here.
def index(request):
    
    ts.loadDatabase(ts.getSearchResults())
    
    return HttpResponse(WordList.objects.all())
