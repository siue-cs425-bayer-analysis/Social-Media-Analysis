#   Carl Grissom
#   sentiment.py   
#   3/27/2019
#   Description: functions for sentiment analysis


import collections
from .models import Tweet, WordList
from nltk.tokenize import TweetTokenizer
from . import sentiment, twitterAuth

def getSearchResults(searchTerm = '#Bayer', tweetCount = 10, popOrRecent='recent', location=''):
    ''' Makes a search request to twitter, returns dictionary of found tweets. '''
    requestDataList = []
    request = twitterAuth.api.GetSearch(searchTerm, 
                                        geocode=location,
                                        count=tweetCount,
                                        max_id=None, 
                                        lang="en", 
                                        result_type=popOrRecent,
                                        return_json=True) # returns a JSON object

    numberOfTweets = tweetCount
    while (numberOfTweets > 0):
        if len(request["statuses"]) != 0:
            for tweets in request['statuses']:
               requestDataList.append(tweets)
        numberOfTweets -= 100
        idOfLastTweet = requestDataList[-1]['id_str'] 
        print(idOfLastTweet)
        if (numberOfTweets > 0):
            request = twitterAuth.api.GetSearch(searchTerm, 
                                                geocode = location,
                                                count = tweetCount,
                                                max_id = idOfLastTweet, 
                                                lang = "en", 
                                                result_type = popOrRecent,
                                                return_json=True) 
    return requestDataList


def loadDatabase(listOfTweets):
    Tweet.objects.all().delete()
    WordList.objects.all().delete()
    tokenizer = TweetTokenizer()
    for tweet in listOfTweets:
        tweetSentiment = sentiment.sentiment_analyzer_score(tweet['full_text'])
        T = Tweet(fullText=tweet['full_text'], 
                            userId=tweet['user']['id_str'],    
                            tweetId=tweet['id_str'],
                            #date = tweet['created_at'], 
                            likes = tweet['favorite_count'], 
                            retweets = tweet['retweet_count'],
                            sentiment = tweetSentiment['compound']
                            )
        T.save()
        tokens = tokenizer.tokenize(tweet['full_text']) 
        for token in tokens:
            W = WordList(word=token) 
            W.save()
            W.tweetId.add(T)
            
    print (WordList.objects.all())
    print('hello')
    return None
