


from django import forms

#class SearchForm(forms.Form):
 # Choices=[('1','reddit'), ('2','twitter')]
  #searchTerm = forms.CharField(label='Search Term', max_length=100)
  #selected = forms.Select(label='Select social media site...', choices= Choices)
  
