default_app_config = "magazine.apps.MagazineAppConfig"
