from django.apps import AppConfig


class Myapp2Config(AppConfig):
    name = 'myapp2'
