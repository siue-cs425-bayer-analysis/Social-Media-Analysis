The `apps/` directory is for third-party Django apps. For example, django-cms, django-haystack, django-storages, and so on.
