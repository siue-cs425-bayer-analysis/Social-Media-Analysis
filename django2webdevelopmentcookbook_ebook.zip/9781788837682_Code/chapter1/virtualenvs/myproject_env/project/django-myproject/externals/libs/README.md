The `libs/` directory is for the Python modules that are required by your project. For example, boto, Requests, Twython, Whoosh, and so on.
