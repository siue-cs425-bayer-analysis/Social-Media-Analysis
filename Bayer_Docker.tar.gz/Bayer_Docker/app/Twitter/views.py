#
#   Author:         Carl Grissom
#   Date:           09/21/2019
#   Project:        Bayer Sentiment Analysis CS 499
#   Filename:       
#   
#   Description:
#
#

from datetime import datetime
from django.shortcuts import render
from django.db.models import Count, Avg
from django.http import HttpResponse
from .forms import twitterSearchForm
# user defined imports 
from .models import Tweet, WordList
from . import twittersearch as ts

# Create your views here.
def index(request):
    form = twitterSearchForm()
    return render(request, 'Twitter/twitter.html', {'form':form})     


def searchResults(request):
    searchterm = request.GET['searchTerm']
    tweetsToget = request.GET['tweetsToreturn']
    start = datetime.now()
    print('Starting twitter Search')
    ts.loadDatabase(ts.getSearchResults(searchterm, int(tweetsToget)))
    #        return HttpResponse("Something went worng, most likely the rate limit for twitter has been meet please wait 15 minutes")
    
    print('Search complete... gathering results')
    
    posTweets = Tweet.objects.values('fullText', 'sentiment').annotate(tweetCount=Count('fullText')).order_by('-sentiment')[:10]
    negTweets = Tweet.objects.values('fullText', 'sentiment').annotate(tweetCount=Count('fullText')).order_by('sentiment')[:10]
    common = Tweet.objects.values('fullText', 'sentiment').annotate(tweetCount=Count('fullText')).order_by('-tweetCount')[:10]
    form = twitterSearchForm()
    wordcountlist = WordList.objects.values('word').annotate(count=Count('word')).order_by('-count')
    
    searchMeta = {'searchterm':searchterm, 
                  'tweetsToget':tweetsToget, 
                  'returnCount':Tweet.objects.count(),
                  'avgSentiment':Tweet.objects.all().aggregate(Avg('sentiment')),
                  'numPosTweet':Tweet.objects.filter(sentiment__gt=0.05).count(),
                  'numNegTweet':Tweet.objects.filter(sentiment__lt=-0.05).count(),
                  'numNeuTweet':Tweet.objects.filter(sentiment__lt=0.05, sentiment__gt=-0.05).count(),
                  'uniqueTweet': Tweet.objects.values('fullText', 'sentiment').annotate(tweetCount=Count('fullText')).order_by('-tweetCount').count()
                  }
    print('Results gathered. Creating context')
    context = {'form':form,
               'posTweets': posTweets,
               'negTweets': negTweets,
               'common': common, 
               'searchMeta': searchMeta,
               'wordCountList': wordcountlist, 
               'range': range(0,6)
               }
    
    print(datetime.now() - start)
    return render(request, 'Twitter/twitter.html', context) 
