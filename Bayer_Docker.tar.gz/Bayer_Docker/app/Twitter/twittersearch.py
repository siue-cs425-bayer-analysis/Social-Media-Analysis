#   Carl Grissom
#   sentiment.py   
#   3/27/2019
#   Description: functions for sentiment analysis

import datetime
import collections
from .models import Tweet, WordList
from nltk.tokenize import TweetTokenizer
from . import sentiment, twitterAuth
from itertools import islice

def getSearchResults(searchTerm = '#Bayer', tweetCount = 100):
    ''' Makes a search request to twitter, returns dictionary of found tweets. '''
    requestDataList = []
    location = ''
    request = twitterAuth.api.GetSearch(searchTerm, 
                                        count=tweetCount,
                                        result_type='recent',
                                        return_json=True) # returns a JSON object

    numberOfTweets = tweetCount - ((len(request["statuses"])) - 1)
    idOfLastTweet = ""
    
    while (numberOfTweets > 0):
        if len(request["statuses"]) != 0:
            for tweets in request['statuses'][:-2]:
               requestDataList.append(tweets)
        numberOfTweets -= (len(request["statuses"])) - 1
        idOfLastTweet = request['statuses'][-1]['id_str'] 
        if (numberOfTweets > 0):
            request = twitterAuth.api.GetSearch(searchTerm, 
                                                count = tweetCount,
                                                max_id = idOfLastTweet, 
                                                lang = "en", 
                                                return_json=True) 
    return requestDataList


def loadDatabase(listOfTweets):
    Tweet.objects.all().delete()
    WordList.objects.all().delete()
    listOfTweetsLen = len(listOfTweets)
    tokenizer = TweetTokenizer()
    
    starttime = datetime.datetime.now()
    
    # database bulk load commented out for word list creation
    #batchSize = 100
    #objects = (Tweet(fullText=tweet['full_text'], 
                    #userId=tweet['user']['id_str'],    
                    #tweetId=tweet['id_str'],
                    ##date = tweet['created_at'], 
                    #likes = tweet['favorite_count'], 
                    #retweets = tweet['retweet_count'],
                    #sentiment = sentiment.sentiment_analyzer_score(tweet['full_text'])['compound']
                #) for tweet in listOfTweets)
    
    #while True:
        #batch = list(islice(objects, batchSize))
        #if not batch:
            #break
        #Tweet.objects.bulk_create(batch, batchSize)
    # end database bulk load
    
    for tweet in listOfTweets:
        try:
            # get entiment
            tweetSentiment = sentiment.sentiment_analyzer_score(tweet['full_text'])
            # create tweet
            T = Tweet.objects.create(fullText=tweet['full_text'], 
                                userId=tweet['user']['id_str'],    
                                tweetId=tweet['id_str'],
                                #date = tweet['created_at'], 
                                likes = tweet['favorite_count'], 
                                retweets = tweet['retweet_count'],
                                sentiment = tweetSentiment['compound']
                            )
            # get tokens
            tokens = tokenizer.tokenize(tweet['full_text']) 
            # create word
            for token in tokens:
                W = WordList(word=token) 
                W.save()
                W.tweetId.add(T)
        except:
            pass
        
    totaltime = datetime.datetime.now() - starttime
    
    print('total Tweets: %i', len(listOfTweets))
    print('total time: %d', totaltime)
            
    return None
